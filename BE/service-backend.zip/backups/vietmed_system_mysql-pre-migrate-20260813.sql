-- MySQL dump 10.13  Distrib 9.6.0, for macos26.4 (arm64)
--
-- Host: 127.0.0.1    Database: vietmed_system_mysql
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('36331a32-d418-4813-b970-85a0e8b245a7','af0717f314a5834eb592df7d3e1d097bc6e68c07d75cb84ed90315d935c295b9','2026-06-16 10:01:52.240','20260616100151_init_mysql',NULL,NULL,'2026-06-16 10:01:51.790',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Attachment`
--

DROP TABLE IF EXISTS `Attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Attachment` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('ENGINEER_PHOTO','MACHINE_PHOTO','BUSINESS_LINE_IMAGE','ERROR_PHOTO','HANDOVER_MINUTES','MAINTENANCE_FORM','PART_INVOICE','ACCEPTANCE_PDF','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `originalName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storedName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadedByEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deletedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Attachment_entityType_entityId_idx` (`entityType`,`entityId`),
  KEY `Attachment_type_idx` (`type`),
  KEY `Attachment_uploadedById_idx` (`uploadedById`),
  KEY `Attachment_createdAt_idx` (`createdAt`),
  CONSTRAINT `Attachment_uploadedById_fkey` FOREIGN KEY (`uploadedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Attachment`
--

LOCK TABLES `Attachment` WRITE;
/*!40000 ALTER TABLE `Attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actorId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actorEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changes` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AuditLog_entityType_entityId_idx` (`entityType`,`entityId`),
  KEY `AuditLog_actorId_idx` (`actorId`),
  KEY `AuditLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `AuditLog_actorId_fkey` FOREIGN KEY (`actorId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
INSERT INTO `AuditLog` VALUES ('cmqjc7g380006m1pmse0m7m52','CREATE','Machine','cmqjc7g1b0001m1pmmuxpzwf7','cmpp63d0d0004m1xvrlrmgtcj','admin@vietmed.vn','null','{\"status\": \"ACTIVE\", \"customerId\": null, \"dataStatus\": \"VERIFIED\", \"machineCode\": \"X_CUBE_90_001\", \"serialNumber\": \"NU617YHAGT\", \"createdSource\": \"ADMIN\", \"inventoryStatus\": \"IN_STOCK\"}','2026-06-18 10:08:31.028'),('cmqjcln2v0007m1yalrxs4pek','CREATE','Machine','cmqjcln1j0001m1yawfqiyxjb','cmpp63d0d0004m1xvrlrmgtcj','admin@vietmed.vn','null','{\"status\": \"ACTIVE\", \"customerId\": null, \"dataStatus\": \"VERIFIED\", \"machineCode\": \"CL-900I-001\", \"serialNumber\": \"T1HJ6714FW\", \"createdSource\": \"ADMIN\", \"inventoryStatus\": \"IN_STOCK\"}','2026-06-18 10:19:33.272');
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BusinessLine`
--

DROP TABLE IF EXISTS `BusinessLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BusinessLine` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `manufacturer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageUrl` text COLLATE utf8mb4_unicode_ci,
  `productCategory` enum('ULTRASOUND','LAB_TESTING','BIOCHEMISTRY','IMMUNOLOGY','HEMATOLOGY','X_RAY','ENDOSCOPY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `countryOfOrigin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expertiseGroup` enum('IMAGING','LAB_TESTING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IMAGING',
  `productIndustryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `managerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BusinessLine_code_key` (`code`),
  KEY `BusinessLine_productIndustryId_fkey` (`productIndustryId`),
  KEY `BusinessLine_managerId_fkey` (`managerId`),
  CONSTRAINT `BusinessLine_managerId_fkey` FOREIGN KEY (`managerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `BusinessLine_productIndustryId_fkey` FOREIGN KEY (`productIndustryId`) REFERENCES `ProductIndustry` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BusinessLine`
--

LOCK TABLES `BusinessLine` WRITE;
/*!40000 ALTER TABLE `BusinessLine` DISABLE KEYS */;
INSERT INTO `BusinessLine` VALUES ('cmq2jklrt001oi5qylql90dd0','PRODUCT-ULTRASOUND','Máy siêu âm','ACTIVE',NULL,'https://eadn-wc01-13349240.nxedge.io/wp-content/uploads/2021/10/Alpinion-Logo.png','ULTRASOUND',NULL,NULL,NULL,NULL,NULL,'Sản phẩm chẩn đoán hình ảnh - máy siêu âm',NULL,'IMAGING','cmq2kls4p001ki5a2q7a1joi8',NULL,'2026-06-06 09:02:37.241','2026-06-11 01:07:37.254'),('cmq2jklrt001ri5qy1ml8bqtu','PRODUCT-XRAY','Máy X-Quang','ACTIVE',NULL,'https://hat-med.com/wp-content/uploads/2024/09/vision-rfd-2.png','X_RAY',NULL,NULL,NULL,NULL,NULL,'Sản phẩm chẩn đoán hình ảnh - X-Quang',NULL,'IMAGING','cmq2kls4p001ki5a2q7a1joi8',NULL,'2026-06-06 09:02:37.241','2026-06-11 02:17:51.931'),('cmq2jklrt001ti5qy4c8sa3d9','PRODUCT-BIOCHEMISTRY','Máy xét nghiệm sinh hóa','ACTIVE',NULL,'https://brandlogovector.com/wp-content/uploads/2022/06/Mindray-Logo-Small.png','BIOCHEMISTRY',NULL,NULL,NULL,NULL,NULL,'Sản phẩm xét nghiệm - máy sinh hóa',NULL,'LAB_TESTING','cmq2kls4p001li5a2tqr5hwnp',NULL,'2026-06-06 09:02:37.241','2026-06-11 02:16:43.409'),('cmq2jklsa001vi5qygnbxt0tx','PRODUCT-IMMUNOLOGY','Máy miễn dịch','ACTIVE',NULL,'https://brandlogovector.com/wp-content/uploads/2022/06/Mindray-Logo-Small.png','IMMUNOLOGY',NULL,NULL,NULL,NULL,NULL,'Sản phẩm xét nghiệm - máy miễn dịch',NULL,'LAB_TESTING','cmq2kls4p001li5a2tqr5hwnp',NULL,'2026-06-06 09:02:37.241','2026-06-09 20:27:08.436'),('cmq2jklsc001xi5qyvam5jeoe','PRODUCT-HEMATOLOGY','Máy xét nghiệm huyết học','ACTIVE',NULL,'https://brandlogovector.com/wp-content/uploads/2022/06/Mindray-Logo-Small.png','HEMATOLOGY',NULL,NULL,NULL,NULL,NULL,'Sản phẩm xét nghiệm - máy huyết học',NULL,'LAB_TESTING','cmq2kls4p001li5a2tqr5hwnp',NULL,'2026-06-06 09:02:37.241','2026-06-11 02:16:33.081'),('product-endoscopy','PRODUCT-ENDOSCOPY','Máy nội soi','ACTIVE',NULL,'https://s3-symbol-logo.tradingview.com/sonoscape-medical--600.png','ENDOSCOPY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IMAGING','cmq2kls4p001ki5a2q7a1joi8',NULL,'2026-06-07 04:22:53.193','2026-06-11 02:16:05.332'),('product-lab-testing','PRODUCT-LAB-TESTING','Máy xét nghiệm khác','ACTIVE',NULL,'https://brandlogovector.com/wp-content/uploads/2022/06/Mindray-Logo-Small.png','LAB_TESTING',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LAB_TESTING','cmq2kls4p001li5a2tqr5hwnp',NULL,'2026-06-07 04:22:53.193','2026-06-09 19:17:32.836'),('product-physiotherapy','PRODUCT-PHYSIOTHERAPY','Máy VLTL','ACTIVE',NULL,'https://scontent.fhan15-2.fna.fbcdn.net/v/t39.30808-6/395834039_831607128755017_6646625476980801700_n.jpg?stp=dst-jpg_tt6&cstp=mx446x446&ctp=s446x446&_nc_cat=103&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=5FxziVP2q98Q7kNvwFgGBXT&_nc_oc=Adpmf5ig2mkiMTwBgndBCam8zOjchTP8qeqdcWbt-4odY0_ROEU24AwOuUhbp8U7SvrJnPAK4L02x3pZ8-Fh2_kl&_nc_zt=23&_nc_ht=scontent.fhan15-2.fna&_nc_gid=JJsZz7ExNK7F344p85W2JQ&_nc_ss=7b289&oh=00_Af_o7TeymUb8xS5eknddMLobK7y0PDHizCztQh7yqkv0gg&oe=6A305773','OTHER',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IMAGING','cmq2kls4p001mi5a2jyhsy764',NULL,'2026-06-07 04:22:53.193','2026-06-11 02:15:28.355');
/*!40000 ALTER TABLE `BusinessLine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComponentAccessory`
--

DROP TABLE IF EXISTS `ComponentAccessory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ComponentAccessory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requiresSerial` tinyint(1) NOT NULL DEFAULT '1',
  `sortOrder` int NOT NULL DEFAULT '0',
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `componentId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ComponentAccessory_componentId_code_key` (`componentId`,`code`),
  KEY `ComponentAccessory_componentId_idx` (`componentId`),
  KEY `ComponentAccessory_status_idx` (`status`),
  CONSTRAINT `ComponentAccessory_componentId_fkey` FOREIGN KEY (`componentId`) REFERENCES `MachineComponent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComponentAccessory`
--

LOCK TABLES `ComponentAccessory` WRITE;
/*!40000 ALTER TABLE `ComponentAccessory` DISABLE KEYS */;
/*!40000 ALTER TABLE `ComponentAccessory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Customer` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hospitalName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerType` enum('HOSPITAL','CLINIC','LAB','DISTRIBUTOR','UNIVERSITY','COMPANY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HOSPITAL',
  `status` enum('ACTIVE','INACTIVE','POTENTIAL','BLACKLISTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `taxCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPosition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ward` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fullAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `regionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Customer_customerCode_key` (`customerCode`),
  KEY `Customer_regionId_fkey` (`regionId`),
  CONSTRAINT `Customer_regionId_fkey` FOREIGN KEY (`regionId`) REFERENCES `Region` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DailyWorkNote`
--

DROP TABLE IF EXISTS `DailyWorkNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DailyWorkNote` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workDate` datetime(3) NOT NULL,
  `startTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DailyWorkNote_userId_workDate_idx` (`userId`,`workDate`),
  CONSTRAINT `DailyWorkNote_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DailyWorkNote`
--

LOCK TABLES `DailyWorkNote` WRITE;
/*!40000 ALTER TABLE `DailyWorkNote` DISABLE KEYS */;
/*!40000 ALTER TABLE `DailyWorkNote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EngineerProfile`
--

DROP TABLE IF EXISTS `EngineerProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EngineerProfile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employeeCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateOfBirth` datetime(3) DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workStartDate` datetime(3) DEFAULT NULL,
  `specialties` json NOT NULL,
  `expertiseGroup` enum('IMAGING','LAB_TESTING') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificateNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photoUrl` text COLLATE utf8mb4_unicode_ci,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `EngineerProfile_userId_key` (`userId`),
  UNIQUE KEY `EngineerProfile_employeeCode_key` (`employeeCode`),
  CONSTRAINT `EngineerProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EngineerProfile`
--

LOCK TABLES `EngineerProfile` WRITE;
/*!40000 ALTER TABLE `EngineerProfile` DISABLE KEYS */;
INSERT INTO `EngineerProfile` VALUES ('cmq7izu9v000hm1jhnx7w4euz','cmq7izu8w000dm1jh8q727m7r','CDHA-001','1995-07-06 17:00:00.000','Kỹ sư','Chẩn đoán hình ảnh','2018-01-31 17:00:00.000','[]','IMAGING','02','https://img.icons8.com/color/1200/user-male-circle--v7.jpg',NULL,'2026-06-09 20:45:19.364','2026-06-10 19:28:25.650'),('cmq7rxkvi0005m10wyxlj2o89','cmq7rxkuf0001m10wsu7x67rg','CDHA_002','2003-07-26 17:00:00.000','Kỹ Sư','Chẩn đoán hình ảnh','2025-12-09 17:00:00.000','[]',NULL,'02','https://i.pinimg.com/736x/b1/88/c6/b188c6801ad1d71d3c962c6e4aa2d0cf.jpg',NULL,'2026-06-10 00:55:30.415','2026-06-11 00:37:33.695'),('cmq8vssde0005m1ssk72ofcpd','cmpp63d0d0004m1xvrlrmgtcj',NULL,NULL,'Phó Tổng Giám Đốc - Trưởng Phòng Kỹ Thuật','Kỹ Thuật',NULL,'[]','IMAGING',NULL,'https://static.vecteezy.com/system/resources/previews/054/944/152/non_2x/user-profile-or-my-account-avatar-login-icon-with-man-male-face-smile-symbol-flat-human-person-member-sign-isolated-on-white-background-vector.jpg',NULL,'2026-06-10 19:31:31.490','2026-06-14 23:11:58.312'),('cmq96sfyo000hm1ti8wl3xhv9','cmq96sfy4000dm1tii51br5ab','XN_001','2000-11-10 17:00:00.000','Kỹ sư','Xét nghiệm','2022-05-15 17:00:00.000','[]',NULL,'02','https://img.magnific.com/premium-vector/woman-profile-cartoon_18591-58480.jpg?semt=ais_hybrid&w=740&q=80',NULL,'2026-06-11 00:39:11.185','2026-06-11 00:39:11.185'),('cmq96vjup000nm1ti22a00van','cmq96vju4000jm1tiuaq0choh','CDHA_003','1982-11-22 17:00:00.000','Kỹ sư','Kỹ Thuật','2006-10-10 17:00:00.000','[]','IMAGING','02','https://static.vecteezy.com/system/resources/previews/051/270/245/non_2x/cartoon-people-avatar-minimalist-human-avatar-versatile-icon-for-online-projects-an-avatar-for-the-profile-picture-of-someone-vector.jpg',NULL,'2026-06-11 00:41:36.194','2026-06-14 23:31:33.675'),('cmq96z488000xm1tirklu6jyi','cmq96z47q000tm1ti9jlg8l3u','XN_002','1987-12-10 17:00:00.000','Trưởng phòng Kỹ Thuật','Xét Nghiệm','2006-11-09 17:00:00.000','[]',NULL,'02','https://png.pngtree.com/png-vector/20220817/ourmid/pngtree-cartoon-man-avatar-vector-ilustration-png-image_6111064.png',NULL,'2026-06-11 00:44:22.569','2026-06-11 00:44:22.569'),('cmq971qfo0013m1ti59jfxv21','cmq971qfd000zm1ti5xdwtnet','XN_003','1994-05-20 17:00:00.000','Kỹ sư','Xét nghiệm','2017-05-09 17:00:00.000','[]',NULL,'02','https://img.freepik.com/premium-vector/businessman-avatar-illustration-cartoon-user-portrait-user-profile-icon_118339-4394.jpg',NULL,'2026-06-11 00:46:24.661','2026-06-11 00:46:24.661'),('cmq973taa0019m1ti5y5jx7s5','cmq973t9s0015m1tilq3c7bm1','XN_004','1996-07-19 17:00:00.000','Kỹ sư','Xét Nghiệm','2021-05-11 17:00:00.000','[]',NULL,'02','https://png.pngtree.com/png-vector/20220817/ourmid/pngtree-women-cartoon-avatar-in-flat-style-png-image_6110776.png',NULL,'2026-06-11 00:48:01.667','2026-06-11 00:48:01.667');
/*!40000 ALTER TABLE `EngineerProfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Machine`
--

DROP TABLE IF EXISTS `Machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Machine` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `machineCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serialNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imageUrl` text COLLATE utf8mb4_unicode_ci,
  `modelName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productCategory` enum('ULTRASOUND','LAB_TESTING','BIOCHEMISTRY','IMMUNOLOGY','HEMATOLOGY','X_RAY','ENDOSCOPY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `productLine` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','MAINTENANCE','REPAIRING','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `inventoryStatus` enum('IN_STOCK','ACCESSORY_SPLIT','INSTALLED','RESERVED','RETURNED','SOLD') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN_STOCK',
  `dataStatus` enum('PENDING_REVIEW','VERIFIED','NEEDS_UPDATE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VERIFIED',
  `createdSource` enum('ADMIN','ENGINEER','IMPORT','SYSTEM') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ADMIN',
  `manufacturingDate` datetime(3) DEFAULT NULL,
  `warehouseImportDate` datetime(3) DEFAULT NULL,
  `installDate` datetime(3) DEFAULT NULL,
  `warrantyStartDate` datetime(3) DEFAULT NULL,
  `warrantyEndDate` datetime(3) DEFAULT NULL,
  `accessoriesSnapshot` json NOT NULL,
  `businessLineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `machineModelId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primaryEngineerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Machine_serialNumber_key` (`serialNumber`),
  UNIQUE KEY `Machine_machineCode_key` (`machineCode`),
  KEY `Machine_businessLineId_fkey` (`businessLineId`),
  KEY `Machine_machineModelId_fkey` (`machineModelId`),
  KEY `Machine_customerId_fkey` (`customerId`),
  KEY `Machine_installedById_fkey` (`installedById`),
  KEY `Machine_primaryEngineerId_fkey` (`primaryEngineerId`),
  CONSTRAINT `Machine_businessLineId_fkey` FOREIGN KEY (`businessLineId`) REFERENCES `BusinessLine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Machine_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Machine_installedById_fkey` FOREIGN KEY (`installedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Machine_machineModelId_fkey` FOREIGN KEY (`machineModelId`) REFERENCES `MachineModel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Machine_primaryEngineerId_fkey` FOREIGN KEY (`primaryEngineerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Machine`
--

LOCK TABLES `Machine` WRITE;
/*!40000 ALTER TABLE `Machine` DISABLE KEYS */;
INSERT INTO `Machine` VALUES ('cmqjc7g1b0001m1pmmuxpzwf7','X_CUBE_90_001','NU617YHAGT',NULL,NULL,'Máy siêu âm X-CUBE 90',NULL,'Alpinion','ULTRASOUND','Máy siêu âm','ACTIVE','IN_STOCK','VERIFIED','ADMIN',NULL,'2026-06-18 00:00:00.000',NULL,NULL,NULL,'[{\"id\": \"cmqjc7g2c0002m1pm11m3p8e9\", \"code\": \"C1-6CT\", \"name\": \"C1-6CT\", \"note\": null, \"description\": null, \"serialNumber\": \"HNKOQ6571\", \"componentAccessoryId\": null}, {\"id\": \"cmqjc7g2c0004m1pmo0nwbwh0\", \"code\": \"L3-12\", \"name\": \"L3-12\", \"note\": null, \"description\": null, \"serialNumber\": \"U7891GTYU5\", \"componentAccessoryId\": null}, {\"id\": \"cmqjc7g2c0003m1pmn315fg55\", \"code\": \"L3-15H\", \"name\": \"L3-15H\", \"note\": null, \"description\": null, \"serialNumber\": \"YUU1TGFT67\", \"componentAccessoryId\": null}]','cmq2jklrt001oi5qylql90dd0','cmpz8m254000dm1zb9ylasdmz',NULL,NULL,NULL,'2026-06-18 10:08:30.959','2026-06-18 10:08:31.003'),('cmqjcln1j0001m1yawfqiyxjb','CL-900I-001','T1HJ6714FW',NULL,NULL,'CL-900i',NULL,'Mindray','IMMUNOLOGY',NULL,'ACTIVE','IN_STOCK','VERIFIED','ADMIN',NULL,'2026-06-18 00:00:00.000',NULL,NULL,NULL,'[{\"id\": \"cmqjcln270002m1yahuqdh8d6\", \"code\": \"Bộ dây nguồn - AC0912\", \"name\": \"Bộ dây nguồn - AC0912\", \"note\": null, \"description\": null, \"serialNumber\": null, \"componentAccessoryId\": null}, {\"id\": \"cmqjcln270003m1yagkouhf0g\", \"code\": \"Bộ kit test - HNM189\", \"name\": \"Bộ kit test - HNM189\", \"note\": null, \"description\": null, \"serialNumber\": null, \"componentAccessoryId\": null}, {\"id\": \"cmqjcln270005m1yafhtsa5ev\", \"code\": \"Dây soi EC-350\", \"name\": \"Dây soi EC-350\", \"note\": null, \"description\": null, \"serialNumber\": null, \"componentAccessoryId\": null}, {\"id\": \"cmqjcln270004m1yaybwbpz98\", \"code\": \"Dây soi EG-350\", \"name\": \"Dây soi EG-350\", \"note\": null, \"description\": null, \"serialNumber\": null, \"componentAccessoryId\": null}]','cmq2jklsa001vi5qygnbxt0tx','cmq2jkltg002ti5qy8gcr1ect',NULL,NULL,NULL,'2026-06-18 10:19:33.223','2026-06-18 10:19:33.254');
/*!40000 ALTER TABLE `Machine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MachineAccessory`
--

DROP TABLE IF EXISTS `MachineAccessory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MachineAccessory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `componentAccessoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serialNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MachineAccessory_serialNumber_key` (`serialNumber`),
  KEY `MachineAccessory_machineId_idx` (`machineId`),
  KEY `MachineAccessory_componentAccessoryId_idx` (`componentAccessoryId`),
  KEY `MachineAccessory_name_idx` (`name`),
  CONSTRAINT `MachineAccessory_componentAccessoryId_fkey` FOREIGN KEY (`componentAccessoryId`) REFERENCES `ComponentAccessory` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineAccessory_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MachineAccessory`
--

LOCK TABLES `MachineAccessory` WRITE;
/*!40000 ALTER TABLE `MachineAccessory` DISABLE KEYS */;
INSERT INTO `MachineAccessory` VALUES ('cmqjc7g2c0002m1pm11m3p8e9','cmqjc7g1b0001m1pmmuxpzwf7',NULL,'C1-6CT','C1-6CT','HNKOQ6571',NULL,NULL,'2026-06-18 10:08:30.997','2026-06-18 10:08:30.997'),('cmqjc7g2c0003m1pmn315fg55','cmqjc7g1b0001m1pmmuxpzwf7',NULL,'L3-15H','L3-15H','YUU1TGFT67',NULL,NULL,'2026-06-18 10:08:30.997','2026-06-18 10:08:30.997'),('cmqjc7g2c0004m1pmo0nwbwh0','cmqjc7g1b0001m1pmmuxpzwf7',NULL,'L3-12','L3-12','U7891GTYU5',NULL,NULL,'2026-06-18 10:08:30.997','2026-06-18 10:08:30.997'),('cmqjcln270002m1yahuqdh8d6','cmqjcln1j0001m1yawfqiyxjb',NULL,'Bộ dây nguồn - AC0912','Bộ dây nguồn - AC0912',NULL,NULL,NULL,'2026-06-18 10:19:33.247','2026-06-18 10:19:33.247'),('cmqjcln270003m1yagkouhf0g','cmqjcln1j0001m1yawfqiyxjb',NULL,'Bộ kit test - HNM189','Bộ kit test - HNM189',NULL,NULL,NULL,'2026-06-18 10:19:33.247','2026-06-18 10:19:33.247'),('cmqjcln270004m1yaybwbpz98','cmqjcln1j0001m1yawfqiyxjb',NULL,'Dây soi EG-350','Dây soi EG-350',NULL,NULL,NULL,'2026-06-18 10:19:33.247','2026-06-18 10:19:33.247'),('cmqjcln270005m1yafhtsa5ev','cmqjcln1j0001m1yawfqiyxjb',NULL,'Dây soi EC-350','Dây soi EC-350',NULL,NULL,NULL,'2026-06-18 10:19:33.247','2026-06-18 10:19:33.247');
/*!40000 ALTER TABLE `MachineAccessory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MachineComponent`
--

DROP TABLE IF EXISTS `MachineComponent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MachineComponent` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `machineModelId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessories` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MachineComponent_machineModelId_code_key` (`machineModelId`,`code`),
  KEY `MachineComponent_machineModelId_idx` (`machineModelId`),
  KEY `MachineComponent_status_idx` (`status`),
  CONSTRAINT `MachineComponent_machineModelId_fkey` FOREIGN KEY (`machineModelId`) REFERENCES `MachineModel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MachineComponent`
--

LOCK TABLES `MachineComponent` WRITE;
/*!40000 ALTER TABLE `MachineComponent` DISABLE KEYS */;
/*!40000 ALTER TABLE `MachineComponent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MachineInstallation`
--

DROP TABLE IF EXISTS `MachineInstallation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MachineInstallation` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDING','INSTALLED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INSTALLED',
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plannedMachineModelId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plannedModelName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessLineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installedAt` datetime(3) NOT NULL,
  `accessories` json NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoverInstallerName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoverInstallerPosition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoverVehicle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handoverDepartureDate` datetime(3) DEFAULT NULL,
  `receiverInstallAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiverRepresentative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiverPosition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiverPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installedDeviceItems` json DEFAULT NULL,
  `deviceCondition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deviceConditionNote` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MachineInstallation_code_key` (`code`),
  KEY `MachineInstallation_machineId_idx` (`machineId`),
  KEY `MachineInstallation_plannedMachineModelId_idx` (`plannedMachineModelId`),
  KEY `MachineInstallation_customerId_idx` (`customerId`),
  KEY `MachineInstallation_businessLineId_idx` (`businessLineId`),
  KEY `MachineInstallation_installedById_idx` (`installedById`),
  KEY `MachineInstallation_installedAt_idx` (`installedAt`),
  KEY `MachineInstallation_status_idx` (`status`),
  CONSTRAINT `MachineInstallation_businessLineId_fkey` FOREIGN KEY (`businessLineId`) REFERENCES `BusinessLine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineInstallation_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `MachineInstallation_installedById_fkey` FOREIGN KEY (`installedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineInstallation_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineInstallation_plannedMachineModelId_fkey` FOREIGN KEY (`plannedMachineModelId`) REFERENCES `MachineModel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MachineInstallation`
--

LOCK TABLES `MachineInstallation` WRITE;
/*!40000 ALTER TABLE `MachineInstallation` DISABLE KEYS */;
/*!40000 ALTER TABLE `MachineInstallation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MachineInventoryMovement`
--

DROP TABLE IF EXISTS `MachineInventoryMovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MachineInventoryMovement` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('IMPORT','SPLIT_ACCESSORY','RESERVE','INSTALL','RETURN','SELL','ADJUST_STATUS') COLLATE utf8mb4_unicode_ci NOT NULL,
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromStatus` enum('IN_STOCK','ACCESSORY_SPLIT','INSTALLED','RESERVED','RETURNED','SOLD') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toStatus` enum('IN_STOCK','ACCESSORY_SPLIT','INSTALLED','RESERVED','RETURNED','SOLD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `occurredAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MachineInventoryMovement_code_key` (`code`),
  KEY `MachineInventoryMovement_machineId_fkey` (`machineId`),
  KEY `MachineInventoryMovement_customerId_fkey` (`customerId`),
  KEY `MachineInventoryMovement_createdById_fkey` (`createdById`),
  CONSTRAINT `MachineInventoryMovement_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineInventoryMovement_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MachineInventoryMovement_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MachineInventoryMovement`
--

LOCK TABLES `MachineInventoryMovement` WRITE;
/*!40000 ALTER TABLE `MachineInventoryMovement` DISABLE KEYS */;
/*!40000 ALTER TABLE `MachineInventoryMovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MachineModel`
--

DROP TABLE IF EXISTS `MachineModel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MachineModel` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `businessLineId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCategory` enum('ULTRASOUND','LAB_TESTING','BIOCHEMISTRY','IMMUNOLOGY','HEMATOLOGY','X_RAY','ENDOSCOPY','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OTHER',
  `productLine` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MachineModel_businessLineId_code_key` (`businessLineId`,`code`),
  KEY `MachineModel_businessLineId_idx` (`businessLineId`),
  KEY `MachineModel_status_idx` (`status`),
  CONSTRAINT `MachineModel_businessLineId_fkey` FOREIGN KEY (`businessLineId`) REFERENCES `BusinessLine` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MachineModel`
--

LOCK TABLES `MachineModel` WRITE;
/*!40000 ALTER TABLE `MachineModel` DISABLE KEYS */;
INSERT INTO `MachineModel` VALUES ('cmpz8m24u0007m1zbw970jf1x','X-CUBE-50','Máy siêu âm X-CUBE 50','Máy siêu âm X-CUBE 50','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.798','2026-06-07 04:22:53.193'),('cmpz8m2510009m1zbxxn2thj6','X-CUBE-60','Máy siêu âm X-CUBE 60','Máy siêu âm X-CUBE 60','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.806','2026-06-07 04:22:53.193'),('cmpz8m252000bm1zbf5bbf2q3','X-CUBE-70','Máy siêu âm X-CUBE 70','Máy siêu âm X-CUBE 70','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.807','2026-06-07 04:22:53.193'),('cmpz8m254000dm1zb9ylasdmz','X-CUBE-90','Máy siêu âm X-CUBE 90','Máy siêu âm X-CUBE 90','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.809','2026-06-07 04:22:53.193'),('cmpz8m255000fm1zbni1jx6r0','X-CUBE-I8','Máy siêu âm xách tay X-CUBE i8','Máy siêu âm xách tay X-CUBE i8','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm xách tay',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.810','2026-06-07 04:22:53.193'),('cmpz8m257000hm1zb59qujxdz','X-CUBE-I9','Máy siêu âm xách tay X-CUBE i9','Máy siêu âm xách tay X-CUBE i9','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm xách tay',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.811','2026-06-07 04:22:53.193'),('cmpz8m258000jm1zb6q1eoh85','MINISONO','Siêu âm Minisono','Siêu âm Minisono','ACTIVE','cmq2jklrt001oi5qylql90dd0','Alpinion','ULTRASOUND','Máy siêu âm xách tay',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.812','2026-06-07 04:22:53.193'),('cmpz8m259000lm1zbgjzda7db','BA-88A','Máy xét nghiệm sinh hoá bán tự động BA-88A','Máy xét nghiệm sinh hoá bán tự động BA-88A','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.813','2026-06-07 04:22:53.193'),('cmpz8m25a000nm1zb0wsxyed9','BS-1000M','Máy xét nghiệm sinh hoá tự động BS-1000M','Máy xét nghiệm sinh hoá tự động BS-1000M','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.814','2026-06-07 04:22:53.193'),('cmpz8m25b000pm1zbykusze85','BS-240E','Máy xét nghiệm sinh hoá tự động BS-240E','Máy xét nghiệm sinh hoá tự động BS-240E','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.815','2026-06-07 04:22:53.193'),('cmpz8m25b000rm1zbg5xy4tl2','BS-360E','Máy xét nghiệm sinh hoá tự động BS-360E','Máy xét nghiệm sinh hoá tự động BS-360E','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.816','2026-06-07 04:22:53.193'),('cmpz8m25d000tm1zbjjkloxlv','BS-430','Máy xét nghiệm sinh hoá tự động BS-430','Máy xét nghiệm sinh hoá tự động BS-430','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.817','2026-06-07 04:22:53.193'),('cmpz8m25f000vm1zbwzcif253','BS-600M','Máy xét nghiệm sinh hoá tự động BS-600M','Máy xét nghiệm sinh hoá tự động BS-600M','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY','Sinh hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.819','2026-06-07 04:22:53.193'),('cmpz8m25f000xm1zbk5j3dkmy','BC-6800-PLUS','Máy xét nghiệm huyết học 5 thành phần BC-6800 Plus','Máy xét nghiệm huyết học 5 thành phần BC-6800 Plus','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.820','2026-06-07 04:22:53.193'),('cmpz8m25g000zm1zbeytctiyf','BC-6000','Máy xét nghiệm huyết học 6 thành phần BC-6000','Máy xét nghiệm huyết học 6 thành phần BC-6000','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.821','2026-06-07 04:22:53.193'),('cmpz8m25h0011m1zb2gi1tbsz','BC-20S','Máy xét nghiệm huyết học tự động BC-20s','Máy xét nghiệm huyết học tự động BC-20s','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.822','2026-06-07 04:22:53.193'),('cmpz8m25i0013m1zb5c8q6pji','BC-30S','Máy xét nghiệm huyết học tự động BC-30s','Máy xét nghiệm huyết học tự động BC-30s','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.822','2026-06-07 04:22:53.193'),('cmpz8m25i0015m1zb33o3v4nk','BC-5380','Máy xét nghiệm huyết học tự động BC-5380','Máy xét nghiệm huyết học tự động BC-5380','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.823','2026-06-07 04:22:53.193'),('cmpz8m25j0017m1zbr0aspe5o','BC-700B','Máy xét nghiệm huyết học tự động BC-700(B)','Máy xét nghiệm huyết học tự động BC-700(B)','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.824','2026-06-07 04:22:53.193'),('cmpz8m25k0019m1zbusnynod8','BC-760B','Máy xét nghiệm huyết học tự động BC-760(B)','Máy xét nghiệm huyết học tự động BC-760(B)','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY','Huyết học',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.825','2026-06-07 04:22:53.193'),('cmpz8m25l001bm1zb2qaiwmn9','CL-1000I','Máy xét nghiệm miễn dịch tự động CL-1000i','Máy xét nghiệm miễn dịch tự động CL-1000i','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Mindray','IMMUNOLOGY','Miễn dịch',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.825','2026-06-07 04:22:53.193'),('cmpz8m25m001dm1zbdpkfodhl','CL-2600I','Máy xét nghiệm miễn dịch tự động CL-2600i','Máy xét nghiệm miễn dịch tự động CL-2600i','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Mindray','IMMUNOLOGY','Miễn dịch',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.826','2026-06-07 04:22:53.193'),('cmpz8m25m001fm1zb5o2foj6y','CL-8000I','Máy xét nghiệm miễn dịch tự động CL-8000i','Máy xét nghiệm miễn dịch tự động CL-8000i','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Mindray','IMMUNOLOGY','Miễn dịch',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.827','2026-06-07 04:22:53.193'),('cmpz8m25n001hm1zbm1fzkrdp','CL-960I','Máy xét nghiệm miễn dịch tự động CL-960i','Máy xét nghiệm miễn dịch tự động CL-960i','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Mindray','IMMUNOLOGY','Miễn dịch',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.827','2026-06-07 04:22:53.193'),('cmpz8m25o001jm1zbin85bpw3','EU-5600-PRO','Máy xét nghiệm nước tiểu EU-5600 Pro','Máy xét nghiệm nước tiểu EU-5600 Pro','ACTIVE','product-lab-testing','Mindray','LAB_TESTING','Nước tiểu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.828','2026-06-07 04:22:53.193'),('cmpz8m25o001lm1zb4ig2jwt4','UA-5600','Máy xét nghiệm nước tiểu UA-5600','Máy xét nghiệm nước tiểu UA-5600','ACTIVE','product-lab-testing','Mindray','LAB_TESTING','Nước tiểu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.829','2026-06-07 04:22:53.193'),('cmpz8m25r001nm1zbutz5hhsq','UA-600','Máy xét nghiệm nước tiểu UA-600','Máy xét nghiệm nước tiểu UA-600','ACTIVE','product-lab-testing','Mindray','LAB_TESTING','Nước tiểu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.831','2026-06-07 04:22:53.193'),('cmpz8m25r001pm1zbnb1mjzae','UA-66','Máy xét nghiệm nước tiểu UA-66','Máy xét nghiệm nước tiểu UA-66','ACTIVE','product-lab-testing','Mindray','LAB_TESTING','Nước tiểu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.832','2026-06-07 04:22:53.193'),('cmpz8m25s001rm1zbm20yn7my','LUMIPULSE-G1200','Máy xét nghiệm miễn dịch tự động Lumipulse G1200','Máy xét nghiệm miễn dịch tự động Lumipulse G1200','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Fujirebio','IMMUNOLOGY','Miễn dịch Fujirebio',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.833','2026-06-07 04:22:53.193'),('cmpz8m25t001tm1zb4gu3mgfp','LUMIPULSE-G600II','Máy xét nghiệm miễn dịch tự động Lumipulse G600II','Máy xét nghiệm miễn dịch tự động Lumipulse G600II','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Fujirebio','IMMUNOLOGY','Miễn dịch Fujirebio',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.834','2026-06-07 04:22:53.193'),('cmpz8m25u001vm1zbys7yquce','QZ-240','Giường massage thủy trị liệu khô QZ-240','Giường massage thủy trị liệu khô QZ-240','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.835','2026-06-07 04:22:53.193'),('cmpz8m25v001xm1zbi3pjdelb','KT-104','Máy điện xung trị liệu KT-104','Máy điện xung trị liệu KT-104','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.835','2026-06-07 04:22:53.193'),('cmpz8m25w001zm1zb7ziwq5id','KT-108','Máy điện xung trị liệu KT-108','Máy điện xung trị liệu KT-108','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.836','2026-06-07 04:22:53.193'),('cmpz8m25x0021m1zb8j8pzq1b','ST-2CL','Máy kéo giãn cột sống kỹ thuật số ST-2CL','Máy kéo giãn cột sống kỹ thuật số ST-2CL','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.837','2026-06-07 04:22:53.193'),('cmpz8m25x0023m1zb9jmnojzi','TC-30D-TC-30S','Máy kéo giãn cột sống TC-30D / TC-30S','Máy kéo giãn cột sống TC-30D / TC-30S','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.838','2026-06-07 04:22:53.193'),('cmpz8m25y0025m1zbi8wj315y','MHR-4F-MHR-2F','Máy nhiệt rung trị liệu MHR-4f / MHR-2f','Máy nhiệt rung trị liệu MHR-4f / MHR-2f','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.838','2026-06-07 04:22:53.193'),('cmpz8m25y0027m1zbvfexhe9e','ALB-200H','Máy trị liệu hồng ngoại ALB-200H','Máy trị liệu hồng ngoại ALB-200H','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.839','2026-06-07 04:22:53.193'),('cmpz8m25z0029m1zb68f4fege','HC-5U','Máy ủ ầm kèm túi chườm nhiệt HC-5U','Máy ủ ầm kèm túi chườm nhiệt HC-5U','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.839','2026-06-07 04:22:53.193'),('cmpz8m260002bm1zb1vlzxi23','MT-5D','Máy vi sóng trị liệu MT-5D','Máy vi sóng trị liệu MT-5D','ACTIVE','product-physiotherapy','Minato','OTHER','Vật lý trị liệu',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.840','2026-06-07 04:22:53.193'),('cmpz8m260002dm1zb7quwh4uh','WTS-SERIES','Bộ thiết bị tập vận động cơ WTS-series','Bộ thiết bị tập vận động cơ WTS-series','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.841','2026-06-07 04:22:53.193'),('cmpz8m261002fm1zbxl1ujuxn','STAIR-TRAINER','Cầu thang tập đi cao cấp','Cầu thang tập đi cao cấp','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.841','2026-06-07 04:22:53.193'),('cmpz8m262002hm1zbdlem3ceq','PARALLEL-BARS','Thanh tập đi song song','Thanh tập đi song song','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.842','2026-06-07 04:22:53.193'),('cmpz8m263002jm1zbwxp3yv09','WTS-01','Thiết bị tập vận động Weltonic WTS-01','Thiết bị tập vận động Weltonic WTS-01','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.843','2026-06-07 04:22:53.193'),('cmpz8m264002lm1zb86qhc06f','WTS-02','Thiết bị tập vận động Weltonic WTS-02','Thiết bị tập vận động Weltonic WTS-02','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.844','2026-06-07 04:22:53.193'),('cmpz8m264002nm1zbvnxi5mq2','WTS-03','Thiết bị tập vận động Weltonic WTS-03','Thiết bị tập vận động Weltonic WTS-03','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.845','2026-06-07 04:22:53.193'),('cmpz8m265002pm1zbe50z3txp','WTS-04','Thiết bị tập vận động Weltonic WTS-04','Thiết bị tập vận động Weltonic WTS-04','ACTIVE','product-physiotherapy','Minato','OTHER','Phục hồi chức năng',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.846','2026-06-07 04:22:53.193'),('cmpz8m266002rm1zbv758nh0e','HD-350','Máy nội soi HD-350','Máy nội soi HD-350','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.846','2026-06-07 04:22:53.193'),('cmpz8m267002tm1zb540agx45','HD-500','Máy nội soi HD-500','Máy nội soi HD-500','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.847','2026-06-07 04:22:53.193'),('cmpz8m267002vm1zbuf7e6vm8','HD-550','Máy nội soi HD-550','Máy nội soi HD-550','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.848','2026-06-07 04:22:53.193'),('cmpz8m268002xm1zbd6pke9mk','HD-650','Máy nội soi HD-650','Máy nội soi HD-650','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.849','2026-06-07 04:22:53.193'),('cmpz8m269002zm1zbc6a2e76y','X-2200','Máy nội soi X-2200','Máy nội soi X-2200','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.850','2026-06-07 04:22:53.193'),('cmpz8m26a0031m1zblhml4mhi','X-2600','Máy nội soi X-2600','Máy nội soi X-2600','ACTIVE','product-endoscopy','SonoScape','ENDOSCOPY','Nội soi tiêu hoá',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.851','2026-06-07 04:22:53.193'),('cmpz8m26b0033m1zb6mt7jsd1','HURO-PATH-T','Máy tách chiết tế bào HURO PATH T','Máy tách chiết tế bào HURO PATH T','ACTIVE','product-lab-testing','CelltraZone','LAB_TESTING','Tách chiết tế bào',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.851','2026-06-07 04:22:53.193'),('cmpz8m26c0035m1zbqma7bu25','HURO-PATH-S','Máy tách chiết tế bào HURO PATH S','Máy tách chiết tế bào HURO PATH S','ACTIVE','product-lab-testing','CelltraZone','LAB_TESTING','Tách chiết tế bào',NULL,'Import nhanh từ VietMed.vn. Nguồn: https://vietmed.vn/collections/all','2026-06-04 01:32:30.852','2026-06-07 04:22:53.193'),('cmq2jklsj0025i5qyrv3s8kwh','BC-30S-2','BC-30s','BC-30s','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY',NULL,NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jklsj002bi5qythm8gdv8','LUMIPULSE-G1200-2','Lumipulse G1200','Lumipulse G1200','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Fujirebio','IMMUNOLOGY','Lumipulse',NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jklt3002gi5qyrshr30hm','LUMIPULSE-G3000','Lumipulse G3000','Lumipulse G3000','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Fujirebio','IMMUNOLOGY','Lumipulse',NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jklt3002hi5qyb7te3g4a','BS-430-2','BS-430','BS-430','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY',NULL,NULL,NULL,'2026-06-06 09:02:37.268','2026-06-07 04:22:53.193'),('cmq2jklt7002ji5qy1ako7w0d','MINATO-AE-310S','Minato AE-310S','Minato AE-310S','ACTIVE','product-physiotherapy','Minato','OTHER',NULL,NULL,NULL,'2026-06-06 09:02:37.268','2026-06-07 04:22:53.193'),('cmq2jklt9002li5qyyma6j6i5','AUTOSPIRO-AS-507','Autospiro AS-507','Autospiro AS-507','ACTIVE','product-physiotherapy','Minato','OTHER',NULL,NULL,NULL,'2026-06-06 09:02:37.268','2026-06-07 04:22:53.193'),('cmq2jkltd002ni5qydiy52x5c','BS-240','BS-240','BS-240','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','Mindray','BIOCHEMISTRY',NULL,NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jkltd002pi5qyuqvieuwd','LUMIPULSE-G600II-2','Lumipulse G600II','Lumipulse G600II','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Fujirebio','IMMUNOLOGY','Lumipulse',NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jkltg002ti5qy8gcr1ect','CL-900I','CL-900i','CL-900i','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','Mindray','IMMUNOLOGY',NULL,NULL,NULL,'2026-06-06 09:02:37.268','2026-06-07 04:22:53.193'),('cmq2jklti002vi5qye4qz5hrc','BC-60S','BC-60s','BC-60s','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','Mindray','HEMATOLOGY',NULL,NULL,NULL,'2026-06-06 09:02:37.267','2026-06-07 04:22:53.193'),('cmq2jklti002xi5qy1ll5lrz8','AUTOSPIRO-AS-407','Autospiro AS-407','Autospiro AS-407','ACTIVE','product-physiotherapy','Minato','OTHER',NULL,NULL,NULL,'2026-06-06 09:02:37.268','2026-06-07 04:22:53.193'),('cmq2m9jcn0001i5tgodejwmw4','SONOPRO-X7','SonoPro X7','SonoPro X7','ACTIVE','cmq2jklrt001oi5qylql90dd0','SonoTech','ULTRASOUND','SonoPro',NULL,NULL,'2026-06-06 10:17:59.735','2026-06-07 04:22:53.193'),('cmq2m9jd50003i5tgw3jkp4rl','DP-10','DP-10','DP-10','ACTIVE','cmq2jklrt001oi5qylql90dd0','UNKNOWN','ULTRASOUND','DP',NULL,NULL,'2026-06-06 10:17:59.753','2026-06-07 04:22:53.193'),('cmq2m9jd80005i5tggs5d9tqm','DC-3','DC-3','DC-3','ACTIVE','cmq2jklrt001oi5qylql90dd0','UNKNOWN','ULTRASOUND','DC',NULL,NULL,'2026-06-06 10:17:59.756','2026-06-07 04:22:53.193'),('cmq2m9jda0007i5tgc3xy4ty6','DC-7','DC-7','DC-7','ACTIVE','cmq2jklrt001oi5qylql90dd0','UNKNOWN','ULTRASOUND','DC',NULL,NULL,'2026-06-06 10:17:59.758','2026-06-07 04:22:53.193'),('cmq2m9jdc0009i5tgckey1c3t','DP-50','DP - 50','DP - 50','ACTIVE','cmq2jklrt001oi5qylql90dd0','UNKNOWN','ULTRASOUND','DP',NULL,NULL,'2026-06-06 10:17:59.760','2026-06-07 04:22:53.193'),('cmq2m9jde000bi5tgdd95irsv','XR-VISION-DR','XR Vision DR','XR Vision DR','ACTIVE','cmq2jklrt001ri5qy1ml8bqtu','RadVision','X_RAY','XR Vision',NULL,NULL,'2026-06-06 10:17:59.762','2026-06-07 04:22:53.193'),('cmq2m9jdg000di5tgmhljrqxt','BIOMAX-800','BioMax 800','BioMax 800','ACTIVE','cmq2jklrt001ti5qy4c8sa3d9','BioLab','BIOCHEMISTRY','BioMax',NULL,NULL,'2026-06-06 10:17:59.764','2026-06-07 04:22:53.193'),('cmq2m9jdi000fi5tglqpguj2x','HEMACOUNT-60','HemaCount 60','HemaCount 60','ACTIVE','cmq2jklsc001xi5qyvam5jeoe','HemaCare','HEMATOLOGY','HemaCount',NULL,NULL,'2026-06-06 10:17:59.766','2026-06-07 04:22:53.193'),('cmq2m9jdj000hi5tg5zecywyj','IMMUSTAR-500','ImmuStar 500','ImmuStar 500','ACTIVE','cmq2jklsa001vi5qygnbxt0tx','ImmuMed','IMMUNOLOGY','ImmuStar',NULL,NULL,'2026-06-06 10:17:59.767','2026-06-07 04:22:53.193');
/*!40000 ALTER TABLE `MachineModel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maintenance`
--

DROP TABLE IF EXISTS `Maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Maintenance` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('PERIODIC','WARRANTY','CONTRACT','INTERNAL','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PERIODIC',
  `status` enum('SCHEDULED','ASSIGNED','IN_PROGRESS','COMPLETED','OVERDUE','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SCHEDULED',
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engineerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduledDate` datetime(3) NOT NULL,
  `assignedAt` datetime(3) DEFAULT NULL,
  `startedAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `checklist` json NOT NULL,
  `resultNote` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextDueDate` datetime(3) DEFAULT NULL,
  `usingDepartment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `representative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deviceName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serialNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Maintenance_code_key` (`code`),
  KEY `Maintenance_machineId_fkey` (`machineId`),
  KEY `Maintenance_engineerId_fkey` (`engineerId`),
  CONSTRAINT `Maintenance_engineerId_fkey` FOREIGN KEY (`engineerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Maintenance_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maintenance`
--

LOCK TABLES `Maintenance` WRITE;
/*!40000 ALTER TABLE `Maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `Maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `href` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `readAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Notification_userId_readAt_createdAt_idx` (`userId`,`readAt`,`createdAt`),
  KEY `Notification_entityType_entityId_idx` (`entityType`,`entityId`),
  KEY `Notification_createdById_idx` (`createdById`),
  CONSTRAINT `Notification_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductIndustry`
--

DROP TABLE IF EXISTS `ProductIndustry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductIndustry` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expertiseGroup` enum('IMAGING','LAB_TESTING') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProductIndustry_code_key` (`code`),
  KEY `ProductIndustry_expertiseGroup_idx` (`expertiseGroup`),
  KEY `ProductIndustry_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductIndustry`
--

LOCK TABLES `ProductIndustry` WRITE;
/*!40000 ALTER TABLE `ProductIndustry` DISABLE KEYS */;
INSERT INTO `ProductIndustry` VALUES ('cmq2kls4p001ki5a2q7a1joi8','IMAGING','Chẩn đoán hình ảnh','Ngành hàng chẩn đoán hình ảnh','IMAGING','ACTIVE',1,'2026-06-06 09:31:31.754','2026-06-06 09:31:31.754'),('cmq2kls4p001li5a2tqr5hwnp','LAB_TESTING','Xét nghiệm','Ngành hàng xét nghiệm','LAB_TESTING','ACTIVE',2,'2026-06-06 09:31:31.754','2026-06-06 09:31:31.754'),('cmq2kls4p001mi5a2jyhsy764','PHYSIOTHERAPY','VLTL','Ngành hàng vật lý trị liệu do kỹ sư chẩn đoán hình ảnh quản lý','IMAGING','ACTIVE',3,'2026-06-06 09:31:31.754','2026-06-06 09:31:31.754'),('cmq2kls4q001ni5a2moe3c7bc','ICU','ICU','Ngành hàng ICU do kỹ sư chẩn đoán hình ảnh quản lý','IMAGING','ACTIVE',4,'2026-06-06 09:31:31.754','2026-06-06 09:31:31.754');
/*!40000 ALTER TABLE `ProductIndustry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Region`
--

DROP TABLE IF EXISTS `Region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Region` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Region_code_key` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Region`
--

LOCK TABLES `Region` WRITE;
/*!40000 ALTER TABLE `Region` DISABLE KEYS */;
INSERT INTO `Region` VALUES ('cmpp63cwl0000m1xvjx8agpyd','Ha Noi','HN','2026-05-28 00:24:17.301','2026-06-06 09:31:31.697'),('cmq7j0sja000im1jh6rpg1gwz','Hải Phòng','HP','2026-06-09 20:46:03.766','2026-06-09 20:46:03.766'),('cmq7j118i000jm1jhftkek2fz','Ninh Bình','NB','2026-06-09 20:46:15.043','2026-06-09 20:46:15.043'),('cmq7j1afv000km1jhjulr8xtt','Nghệ An','NA','2026-06-09 20:46:26.971','2026-06-09 20:46:26.971'),('cmq7j1je1000lm1jhrdxxcur4','Thanh Hoá','TH','2026-06-09 20:46:38.569','2026-06-09 20:46:38.569'),('cmq7j21v0000mm1jh49xn4p61','Phú Thọ','PT','2026-06-09 20:47:02.509','2026-06-09 20:47:02.509');
/*!40000 ALTER TABLE `Region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Repair`
--

DROP TABLE IF EXISTS `Repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Repair` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PENDING','ASSIGNED','IN_PROGRESS','WAITING_PARTS','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `priority` enum('LOW','NORMAL','HIGH','URGENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engineerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `assignedAt` datetime(3) DEFAULT NULL,
  `startedAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `resultNote` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerFeedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usingDepartment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `representative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deviceName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serialNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warrantyStatus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conditionAssessment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repairMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Repair_code_key` (`code`),
  KEY `Repair_createdById_idx` (`createdById`),
  KEY `Repair_machineId_fkey` (`machineId`),
  KEY `Repair_engineerId_fkey` (`engineerId`),
  CONSTRAINT `Repair_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Repair_engineerId_fkey` FOREIGN KEY (`engineerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Repair_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Repair`
--

LOCK TABLES `Repair` WRITE;
/*!40000 ALTER TABLE `Repair` DISABLE KEYS */;
/*!40000 ALTER TABLE `Repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Role_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES ('cmpp63cxb0001m1xv4tz5tyla','admin','2026-05-28 00:24:17.328','2026-05-28 00:24:17.328'),('cmpp63cxg0002m1xvwntody49','engineer','2026-05-28 00:24:17.333','2026-05-28 00:24:17.333'),('cmpqngtul0005m1wye102d662','manager','2026-05-29 01:18:25.438','2026-05-29 01:18:25.438');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `roleId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `regionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  KEY `User_roleId_fkey` (`roleId`),
  KEY `User_regionId_fkey` (`regionId`),
  CONSTRAINT `User_regionId_fkey` FOREIGN KEY (`regionId`) REFERENCES `Region` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `User_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('cmpp63d0d0004m1xvrlrmgtcj','admin@vietmed.vn','$2b$10$j70AAAURWXFUV.RpmANmu.ost0qhe1nFnRWGi68yDamGBvjmETk4q','System Admin','0901000001','ACTIVE','cmpp63cxb0001m1xv4tz5tyla','cmpp63cwl0000m1xvjx8agpyd','2026-05-28 00:24:17.437','2026-06-14 23:11:58.300'),('cmq7izu8w000dm1jh8q727m7r','lvhuan@vietmed.vn','$2b$10$JeIbuIBp0WVUvTmuG30NfeXEwWZwVWAz6qbOOnEObvZZxW0FYjMni','Lê Văn Huấn','0987967762','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-09 20:45:19.328','2026-06-10 19:28:25.641'),('cmq7rxkuf0001m10wsu7x67rg','thuynx@vietmed.vn','$2b$10$w/Sy5ZlZgr1QCohn6yUPdeOtof4ydUeDF6VQ0rUsuemPU5yX0EUVG','Nguyễn Xuân Thuỷ','0987967762','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-10 00:55:30.374','2026-06-11 00:37:33.673'),('cmq96sfy4000dm1tii51br5ab','tthuong@vietmed.vn','$2b$10$RVLJBBOMx39mLXpVL9sZqOFgobfO5r/vZowCFvLQRq5rCbZiEQp6G','Trần Thị Hương','0989765436','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-11 00:39:11.165','2026-06-11 00:39:11.165'),('cmq96vju4000jm1tiuaq0choh','lvquang@vietmed.vn','$2b$10$pBV4XwLuKAxbxFAHUqKA7eNZDR4OYqd4nYVIRyVCj7fmuWksjSNdy','Lê Văn Quang','0936334022','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-11 00:41:36.172','2026-06-14 23:31:33.661'),('cmq96z47q000tm1ti9jlg8l3u','dthuynh@vietmed.vn','$2b$10$8l2G5/xXOYs0V/YDKlVocuzEUiwbS/VeG3xSQCflQYXMytqdEykIy','Đỗ Thế Huynh','093633722','ACTIVE','cmpp63cxb0001m1xv4tz5tyla','cmpp63cwl0000m1xvjx8agpyd','2026-06-11 00:44:22.551','2026-06-14 21:01:43.691'),('cmq971qfd000zm1ti5xdwtnet','nvcuong@vietmed.vn','$2b$10$Gx9vx7UBBFykzT3Q7NPGp.XvuSaON1ioZdPypI2VcZGJgqK64PHY2','Nguyễn Văn Cường','0936336722','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-11 00:46:24.649','2026-06-11 00:46:24.649'),('cmq973t9s0015m1tilq3c7bm1','ntmay@vietmed.vn','$2b$10$BOkKMtRxoZXxZ0/GbPHriulG0UAjhRhJuofu3uSnHEPSqW/BeOfa2','Nguyễn Thu May','0987657893','ACTIVE','cmpp63cxg0002m1xvwntody49','cmpp63cwl0000m1xvjx8agpyd','2026-06-11 00:48:01.649','2026-06-11 00:48:01.649');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WarrantyCard`
--

DROP TABLE IF EXISTS `WarrantyCard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WarrantyCard` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','EXPIRED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `installationId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `machineId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issuedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `startDate` datetime(3) NOT NULL,
  `endDate` datetime(3) NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issuedById` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issuedByEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WarrantyCard_code_key` (`code`),
  UNIQUE KEY `WarrantyCard_installationId_key` (`installationId`),
  KEY `WarrantyCard_machineId_idx` (`machineId`),
  KEY `WarrantyCard_customerId_idx` (`customerId`),
  KEY `WarrantyCard_status_idx` (`status`),
  KEY `WarrantyCard_startDate_idx` (`startDate`),
  KEY `WarrantyCard_endDate_idx` (`endDate`),
  KEY `WarrantyCard_issuedById_fkey` (`issuedById`),
  CONSTRAINT `WarrantyCard_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `WarrantyCard_installationId_fkey` FOREIGN KEY (`installationId`) REFERENCES `MachineInstallation` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `WarrantyCard_issuedById_fkey` FOREIGN KEY (`issuedById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `WarrantyCard_machineId_fkey` FOREIGN KEY (`machineId`) REFERENCES `Machine` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WarrantyCard`
--

LOCK TABLES `WarrantyCard` WRITE;
/*!40000 ALTER TABLE `WarrantyCard` DISABLE KEYS */;
/*!40000 ALTER TABLE `WarrantyCard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WeeklyReport`
--

DROP TABLE IF EXISTS `WeeklyReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WeeklyReport` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weekStart` datetime(3) NOT NULL,
  `status` enum('DRAFT','SUBMITTED','APPROVED','NEEDS_REVISION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submittedAt` datetime(3) DEFAULT NULL,
  `reviewedAt` datetime(3) DEFAULT NULL,
  `reviewerId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WeeklyReport_userId_weekStart_key` (`userId`,`weekStart`),
  KEY `WeeklyReport_weekStart_idx` (`weekStart`),
  KEY `WeeklyReport_status_idx` (`status`),
  KEY `WeeklyReport_reviewerId_idx` (`reviewerId`),
  CONSTRAINT `WeeklyReport_reviewerId_fkey` FOREIGN KEY (`reviewerId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `WeeklyReport_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WeeklyReport`
--

LOCK TABLES `WeeklyReport` WRITE;
/*!40000 ALTER TABLE `WeeklyReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `WeeklyReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WeeklyReportRow`
--

DROP TABLE IF EXISTS `WeeklyReportRow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WeeklyReportRow` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workDate` datetime(3) NOT NULL,
  `customer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `machine` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pending` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proposal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `WeeklyReportRow_reportId_sortOrder_idx` (`reportId`,`sortOrder`),
  KEY `WeeklyReportRow_workDate_idx` (`workDate`),
  CONSTRAINT `WeeklyReportRow_reportId_fkey` FOREIGN KEY (`reportId`) REFERENCES `WeeklyReport` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WeeklyReportRow`
--

LOCK TABLES `WeeklyReportRow` WRITE;
/*!40000 ALTER TABLE `WeeklyReportRow` DISABLE KEYS */;
/*!40000 ALTER TABLE `WeeklyReportRow` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 15:17:40
