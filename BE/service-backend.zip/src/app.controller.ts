import { Controller, Get } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getServiceInfo() {
    return this.appService.getServiceInfo();
  }

  @Get('health')
  getHealth() {
    return this.appService.getHealth();
  }
}
